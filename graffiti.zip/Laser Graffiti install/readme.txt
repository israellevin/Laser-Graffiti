Installation:
    Run all three installers from the "install" folder in the correct order:
        1 - python-2.6.4.msi
        2 - PIL-1.1.7.win32-py2.6.exe
        3 - pyglet-1.1.4.msi

Activation:
    Double-click the file "graffiti.py" in the "runtime" folder

Note:
    You will probably want to create a shortcut to "graffiti.py on your desktop
